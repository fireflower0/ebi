# cl-sdl2-gfx

## Overview

Common Lisp autowrap bindings to the [SDL2_gfx](http://www.ferzkopp.net/Software/SDL2_gfx/Docs/html/index.html) library